export class BaseModel {
    _id: any;
    rowCount:any;
    rows:any;
    
}