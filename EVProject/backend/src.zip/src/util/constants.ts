module Constants {

    export const BASE_URL = '/api/v1';
    export const Request_URL = BASE_URL;
    export const resource_URL = BASE_URL;
  
}

export default Constants;